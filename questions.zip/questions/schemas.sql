create schema sales

alter schema sales rename to programming

drop schema programming